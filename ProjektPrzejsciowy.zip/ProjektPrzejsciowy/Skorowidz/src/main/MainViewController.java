package main;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;


import javafx.stage.Stage;

public class MainViewController {

	public MainViewController() {
	}



	@FXML
	private RadioButton wczytaj;

	@FXML
	private RadioButton utworz;

	@FXML
	private RadioButton wyswietl;

	@FXML
	private Button dalej;

	@FXML
	private Button zamknij;

	

	@FXML
	void dalejAction(ActionEvent event) {

	}

	@FXML
	void utworzAction(ActionEvent event) {

	}

	@FXML
	void wczytajAction(ActionEvent event) {

	}

	@FXML
	void wyswietlAction(ActionEvent event) {

	}

	@FXML
	void zamknijAction(ActionEvent event) {
		Stage stage = (Stage) zamknij.getScene().getWindow();
		stage.close();
	}

}
