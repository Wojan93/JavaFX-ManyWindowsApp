package load;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.MenuItem;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.FileChooser.ExtensionFilter;

public class LoadViewController {
	String line;
	HashMap<String, String> map = new HashMap<String, String>();
	private File selectedFile;
	@FXML
	private MenuItem wskaz;

	@FXML
	private MenuItem zapiszDoBazy;

	@FXML
	void wskazAction(ActionEvent event) {
		
		Stage stage = new Stage();
		FileChooser fileChooser = new FileChooser();
		wskaz.setOnAction(e -> {
			fileChooser.setTitle("Wczytaj plik");
			fileChooser.getExtensionFilters().addAll(new ExtensionFilter("Text Files", "*.txt"));
			selectedFile = fileChooser.showOpenDialog(stage);
			if (selectedFile == null) {
				return;
			}
			try {
				BufferedReader br = new BufferedReader(new FileReader(selectedFile));
				while ((line = br.readLine()) != null) {
					String[] parts = line.split(":", 2);
					if (parts.length >= 2) {
						String key = parts[0];
						String value = parts[1];
						map.put(key, value);
					} else {
						System.out.println("ignoring line: " + line);
					}
					}
				for (String key : map.keySet()) {
					System.out.println(key + ":" + map.get(key));
				}
				br.close();
			} catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}

		});

	}

	@FXML
	void zapiszDoBazyAction(ActionEvent event) {
		Stage stage = new Stage();
		FileChooser fileChooser = new FileChooser();
		zapiszDoBazy.setOnAction(e -> {
			fileChooser.setTitle("Zapisz plik");
			savedFile = fileChooser.showSaveDialog(stage);
			if (savedFile != null) {
				try {
					ImageIO.write(SwingFXUtils.fromFXImage(image, null), "png", savedFile);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
		menuPlik.getItems().addAll(openItem, saveItem);
	}

}